package com.verizon.example;

public class concat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a="bhavya";
		String b="sri";
		String c= "+";
		try {
			String c=a+b;

				System.out.println(x[4]);
			  System.out.print(c);
			  }
		catch(ArrayIndexOutOfBoundsException e){
			System.out.print(e.getMessage());
		}
		catch(ArithmeticException e) {
			e.printStackTrace();
		}
		System.out.println("done");
	}
		
		

}
