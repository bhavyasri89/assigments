package com.verizon;

public class AnnotationDemo {
	class A{
		void show() {
			
		}
		public String toString() {
			return "A[getClass()="+getClass()+",hashcode()		}
	}

}
