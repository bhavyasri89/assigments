package com.verizon;

import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;

@Suite
@SelectClasses({ CalculatorTest.class, CalculatorTestTest.class, LoanTest.class })
public class AllTests {

}
