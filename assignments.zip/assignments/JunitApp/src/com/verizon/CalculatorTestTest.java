package com.verizon;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CalculatorTestTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		System.out.println("test class started");
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		System.out.println("testing ended");
	}

	@BeforeEach
	void setUp() throws Exception {
		System.out.println("testing each case method started");
	}

	@AfterEach
	void tearDown() throws Exception {
		System.out.println("test case object is tear down");
	}

	@Test
	void testTestSum() {
		//fail("Not yet implemented");
	}

	@Test
	void testTestDiff() {
		//fail("Not yet implemented");
	}

	@Test
	void testTestProduct() {
		//fail("Not yet implemented");
	}

	@Test
	void testTestDiv() {
		//fail("Not yet implemented");
	}

}
