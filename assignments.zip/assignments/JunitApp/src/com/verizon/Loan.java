package com.verizon;

public class Loan {
	
	int getEmi(int amount) {
		return (amount/12);
	
}

}
