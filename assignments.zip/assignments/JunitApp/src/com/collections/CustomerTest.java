package com.collections;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CustomerTest {

	@Test
	void test() {
		Customer c=new Customer();
		//fail("Not yet implemented");
		assertEquals(c.getBalance(),1000);
	}

}
