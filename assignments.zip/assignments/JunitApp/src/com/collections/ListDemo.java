package com.collections;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class ListDemo {
	public static <E> void main(String[] args) {
		//List l=new ArrayList();
		Set<String> names=new HashSet<>();
		names.add("ravi");
		names.add("vani");
		names.add("hari");
		names.add("sri");
		names.add("kavi");
		names.add("dilip");
		System.out.println(names);
		System.out.println(names.size());
		//l.clear();
		//l.remove(2);
		//l.contains(23);//true or false
	//	System.out.println(l.indexOf("java"));
		//l.lastIndexOf("javatpoint");
	/*	System.out.println(l.isEmpty());
		ArrayList a1=new ArrayList();
		a1.add(45);
		a1.add(32);
		a1.add(76);
		l.retainAll(a1);
		System.out.println(l);
		System.out.println(l.containsAll(a1));
		for(Object o:l)
			System.out.println(o);
		
		Iterator<E> i=(Iterator<E>) l.iterator();
		while(i.hasNext())
			System.out.println(i.next());
		
		System.out.println("lambda");
		l.forEach(x->System.out.println(x));*/
		
		Set<Object> l=new TreeSet<>();
		l.add(23);
		l.add(73);
		l.add(63);
		l.add(45);
		l.add(86);
		System.out.println(l);
		Iterator i=l.iterator();
		while(i.hasNext())
			System.out.println(i.next());
		System.out.println("lambda");
		l.forEach(x->System.out.println(x));
		
	}

}





