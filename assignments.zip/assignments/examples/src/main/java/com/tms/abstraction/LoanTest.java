package com.tms.abstraction;

public class LoanTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Loan=l;
		//HousingLoan h1=new HousingLoan();
		//h=l=h1
		Loan l=new HousingLoan();
		l.applyLoan("ram",200000.00);
		l.submitDocs();
		System.out.println("emi is" + l.getEmi());
		
		l=new VehicleLoan();
		l.applyLoan("raj",10000.00);
		l.submitDocs();
		System.out.println("emi is" + l.getEmi());
		

	}

}
