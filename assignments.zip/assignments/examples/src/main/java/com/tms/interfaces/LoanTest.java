package com.tms.interfaces;

public interface LoanTest {
	public static void main(String[] args) {
	Loan l;
	HousingLoan hl=new HousingLoan();
	l=hl;
	l.applyLoan("ram",200000.00);
	l.submitDocs();
	System.out.println(l.getEmi());
	Surity s1;
	s1=h1;
	s1.submitDocs2();
	VehicleLoan v1=new VehicleLoan();
	s1=v1;
	l=new VehicleLoan();
	l.applyLoan("raj", 10000.00);
	l.submitDocs();
	System.out.println(l.getEmi());
	s1=v1;
	s1.submitDocs2
	}
