package com.tms.interfaces;

interface Loan {//abstract,public}
	
	 void applyLoan(String name,double amount);
	 void submitDocs();
	 int getEmi();

}

