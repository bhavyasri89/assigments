package com.tms.abstraction;

public abstract class Surity {
	abstract void submitDocs();

}
