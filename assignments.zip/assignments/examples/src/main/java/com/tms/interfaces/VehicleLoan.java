package com.tms.interfaces;

public interface VehicleLoan {

}
