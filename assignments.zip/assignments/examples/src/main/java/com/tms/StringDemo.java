package com.tms;
import java.util.Scanner;
import java.util.StringTokenizer;
public class StringDemo {
	public static void main(String[] args) {
		String  name="Verizon Developer";
		String  name123="Verizon Developer";
		String  name1=new String("Verizon Developer");
		/*System.out.println(name.length());//object
		System.out.println(name.toLowerCase());//object
		System.out.println(name.concat("hyd"));
		System.out.println(name.charAt(2));
		System.out.println(name.lastIndexOf("e"));
		
		System.out.println(name.compareTo(name123));
		System.out.println(name.equals(name123));
		System.out.println(name==name123);
		
		char city[]= {'h','y','d'};
		String citys=new String(city);
		
		
		Scanner sc= new Scanner(System.in);
		String comments=sc.nextLine();
		System.out.println(comments);
		String tokens[]=comments.split(" ");
		//more iterations
		for(int i=0;i<tokens.length;i++)
			System.out.println(tokens[i]);
		
		//enhanced for loop
		for(String x:tokens)
			System.out.println(x);*/
		
		//string buffer   
		//mutable and not create multiple objects
		StringBuffer sb=new StringBuffer("java technology");
		//append,insert,delete,reverse(),capacity()
		//ensureCapacity()
		/*sb.append(1999);
		System.out.println(sb);
		System.out.println(sb.insert(3, "xxxx"));
		sb.ensureCapacity(50);
		System.out.println(sb.delete(3, 8));
		System.out.println(sb.reverse());
		StringBuilder sb1=new StringBuilder("java technology");
		sb1.append(1999);
		System.out.println(sb1);
		System.out.println(sb1.insert(3, "xxxx"));
		sb1.ensureCapacity(50);
		System.out.println(sb1.delete(3, 8));
		System.out.println(sb1.reverse());
		String ss="javatechnology";
		StringBuilder sb2=new StringBuilder(ss);
		String sss=sb2.toString();*/
		String line="verizon,building10,raheja mind space,hyderabda ,telangana";
		StringTokenizer st=new StringTokenizer(line,",");
		System.out.println(st.countTokens());
		while(st.hasMoreTokens())
			System.out.println(st.nextToken());
	}

}
