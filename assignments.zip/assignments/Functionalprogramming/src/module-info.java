/**
 * 
 */
/**
 * 
 */
module Functionalprogramming {
}