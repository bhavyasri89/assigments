package java8;
import java.util.Arrays;
import java.util.List;

public class ArraysDemo {
	public static void main(String[] args) {
		int a[]= {4,5,3,6,2,3,1};
		for(int x:a)
			System.out.println(x+" ");
		System.out.println();
		Arrays.sort(a);
		
		for(int x:a)
			System.out.print(x+" ");
		int b[]=new int[5];
		Arrays.fill(b,89);
		for(int x:b)
			System.out.print(x+" ");
		System.out.println(Arrays.compare(a, b));
		//System.out.println("Location:"+Arrays.binarySearch(a,0));
		List<Integer> list=Arrays.asList(5,6,7,2,3,4,9,1);
		System.out.println("==========for each method with lambda=========");
		list.forEach(x->System.out.println(x));
		System.out.println("==========for each method with reference=========");
		list.forEach(System.out::println);
		System.out.println();
	}
	
}
