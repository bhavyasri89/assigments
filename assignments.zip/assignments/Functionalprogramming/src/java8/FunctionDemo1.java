package java8;
@FunctionalInterface
interface Arith{
	int getSum(int a,int b);
	//void show();
}
public class FunctionDemo1 {
	/*int getSum(int a,int b) {
		return a+b;
	}
*/
	public static void main(String[] args) {
		/*
		FunctionalDemo1 f= new FunctionalDemo1();
		int result=f.getSum(4,5);
		System.out.println(result);
		System.out.println(f.getsum(6,7));
		*/
		Arith arith=(a,b)->a+b;
		System.out.println(arith.getSum(5, 6));
		System.out.println(arith.getSum(25, 46));
	}

}
