package java8;
import java.util.StringJoiner;

public class Stringjoiner {
	public static void main(String[] args) {
		StringJoiner joinNames=new StringJoiner(",");//passing comma(,) as delimeter
		joinNames.add("Rahul");
		joinNames.add("Raju");
		joinNames.add("peter");
		joinNames.add("Raheem");
		joinNames.add("Ravi");
		System.out.println(joinNames);
		System.out.println(joinNames.length());
		StringJoiner s1=new StringJoiner("-");
		s1.add("java");
		s1.add("python");
		System.out.println(joinNames.merge(s1));
		
				
	}

	
	


}







	   
	   
