package java8;
@FunctionalInterface
interface Arith3<T>{
	T op(T a,T b);
}

public class FDunctionalDemo3 {
	public static void main(String[] args) {

		Arith3<Integer> arith=( a, b)->a+b;
		System.out.println(arith.op(5,6));
		
		Arith3<Double> arith1=(a,b)->a*a+b*b;
		System.out.println(arith1.op(3.6, 6.2));
		
		Arith3<Float> arith2=(a,b)->(a*a+b*b);
		System.out.println(arith2.op(13.0f, 66.0f));
}
	}