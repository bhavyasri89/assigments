package java8;
@FunctionalInterface
interface Arith8<T>{
	T op(T a,T b);
}

interface Account{
	int getEmi(int amount);
}
public class Generic {
	public static void main(String[] args) {
		Account account=(a)->a/12;
		System.out.println(account.getEmi(60000));

		/*Arith1<Integer> arith=( a, b)->a+b;
		System.out.println(arith.op(5, 6));
		
		Arith1<Double> arith1=(a,b)->a*a+b*b;
		System.out.println(arith1.op(3.6, 6.2));
		
		Arith1<Float> arith2=(a,b)->a*a*a+b*b*b;
		System.out.println(arith2.op(13f, 66f));*/
}
	}