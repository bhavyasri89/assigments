package com.verizon.exceptions;

public class Ex4 {
	
	public static void main(String[] args) throws DepositException{
		
		int amt=1999;
		
		if(amt<1000)
			throw new DepositException("minimum amount is 1000/-");
		else
			System.out.println("Thanks for using the service");	
		}

}
