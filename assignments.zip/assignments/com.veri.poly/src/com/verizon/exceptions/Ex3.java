package com.verizon.exceptions;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class Ex3{
	public void show() throws FileNotFoundException,InterruptedException
	{
		FileReader f=new FileReader("C:\\abc.txt");
		Thread.sleep(5000);
	}
	public static void main(String[] args)throws FileNotFoundException,InterruptedException{
		Ex3 e1=new Ex3();
		e1.show();
			System.out.println("done");
	}
}