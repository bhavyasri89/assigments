package com.verizon.exceptions;

public class DepositException extends Exception{
	
	DepositException(String msg){
		super(msg);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
