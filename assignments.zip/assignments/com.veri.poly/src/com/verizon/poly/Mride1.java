package com.verizon.poly;

public class Mride1 extends Mride {
	final int x=10;
	void sq(int s) {
		System.out.println("cube:"+(s*s*s));
		System.out.println(x);
	}
	public static void main(String[] args) {
		Mride1 m=new Mride1();
		m.sq(4);
		String age="20";
	/*Short
	 * Byte
	 * Integer
	 * Double
	 * Float
	 * Character
	 * Boolean
	 * Long	
	 */
	int a=Integer.parseInt(age);
	System.out.println(a);
	double a1=Double.parseDouble(age);
	System.out.println(a1);
	
	int x=10;
	Integer x0bj=new Integer(x);
	Integer x0bj1=x;//auto boxing
	
	Integer i0bj=new Integer(100);
	}

}
