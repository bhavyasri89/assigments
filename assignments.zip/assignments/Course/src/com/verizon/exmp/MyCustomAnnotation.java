package com.verizon.exmp;
import java.lang.annotation.*;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface MyCustomAnnotation{
	String value() default "verizon,Hyderabad";
	int count() default 9999;
}

