package com.verizon.exmp;

public class MyClass {
	@MyCustomAnnotation()
	public void myannotationMethod() {
		//annotated method implementation
	}

}
