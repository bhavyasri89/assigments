package com.verizon.exmp;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
//model
class Course{
	Integer id;
	String name;
	Double fee;
	public Course(Integer id, String name, Double fee) {
		super();
		this.id = id;
		this.name = name;
		this.fee = fee;
	}
	
	@Override
	public String toString() {
		return "Course [id=" + id + ", name=" + name + ", fee=" + fee + "]";
	}
	
}
interface CourseService{
	String addCourse(Course c);
	String deleteCourse(Integer cId);
	String updateCourse(Integer cId);
	List<Course>listCourses();
}
class CourseServiceImpl implements CourseService{
	List<Course> CourseList=new ArrayList();
	public String addCourse(Course c) {
		CourseList.add(c);
		return "Course Added successfully";
		
	}	
	
	
	public String deleteCourse(Integer cId) {
		Iterator i=CourseList.iterator();
		while(i.hasNext()) {
			Course course=(Course)i.next();
			if(course.id==cId)
				i.remove();
		}
		return "Removed the course";
	}
	
	public String updateCourse(Integer cId) {
		Iterator i=CourseList.iterator();
		while(i.hasNext()) {
			Course course=(Course)i.next();
			if(course.id==cId)
				course.fee=course.fee+1000;
		
	}
	return "Updated successfully";
}


//ui ,test,run,client
public class CourseDemo
	{
	public static void main(String[] args)
	{
		Course c1=new Course(40,"Angular",5000.00);
		Course c2=new Course(30,"React",6000.00);
	CourseService cs=new CourseServiceImpl();
	System.out.println(cs.addCourse(c1));
	System.out.println(cs.addCourse(c2));
	List<Course> returnedList=cs.listCourses();
	//returnedList.forEach(x->System.out.println(x));
	for(Course c:returnedList)
		System.out.print(c);
	
	System.out.println(cs.deleteCourse(30));
	System.out.println(cs.deleteCourse(40));
	List<Course> returnedList=cs.listCourses();
	//returnedList.forEach(x->System.out.println(x));
	for(Course c:returnedList)
		System.out.print(c);
	}
	}
	}






























