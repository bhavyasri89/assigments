package com.verizon;

public class Sum {
	
	public Integer addNum() {
		Integer a=9;
		Integer b=7;
		return a+b;
	}

}
