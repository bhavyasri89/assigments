package com.verizon.test;

import org.testng.annotations.Test;

public class NewTest {
  @Test(priority=2)
  public void f() {
	  System.out.println("done");
  }
  @Test(priority=4)
  public void f1() {
	  System.out.println("done next");
  }
}
