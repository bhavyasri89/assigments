import org.testng.annotations.Test;

public class sumtest {
  @Test
  public void f() {
  }
}
